# PCB layout for basic ecp5

\ ![overview](auto-fab/basic-ecp5-pcb-overview.png)

# Configuration

* 100.1 x 68.1mm
* 1.6 mm FR4, white silkscreen, green/any mask
* 4 layers, 35um copper
 * layer stackup:
    1. CuTop
    2. CuLayer2
    3. CuLayer3
    4. CuBottom
* generated on 2020-07-17 14:36:34.269792, git version 2e8a863
